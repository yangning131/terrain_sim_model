This repository holds the [Gazebo](http://gazebosim.org) model database.

Learn more about the database [here](http://gazebosim.org/tutorials?tut=model_structure&cat=build_robot).

Learn how to contribute models [here](http://gazebosim.org/tutorials?tut=model_contrib&cat=build_robot).
